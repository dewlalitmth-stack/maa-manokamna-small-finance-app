const CACHE='maa-manokamna-v1';
const FILES=['./','./index.html','./manifest.webmanifest','./assets/durga-hero.jpg','./assets/durga-watermark.jpg','./assets/devotional-collage.jpg','./assets/approved-home.jpg','./assets/approved-report.jpg'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(FILES))));
self.addEventListener('fetch',e=>e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request))));
